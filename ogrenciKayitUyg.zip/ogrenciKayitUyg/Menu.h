#ifndef MENU_H
#define MENU_H

class Menu
{
	public:
		Menu();
		~Menu();
		
		void inputAl(char *); 
		int anaEkran(); 
		void giris(); 
		void yeniKayit(); 
		void listele(); 
		void kayitSil(); 
		void kayitBul(); 
		void enYuksekOrtlama(); 
		
};

#endif
