#include <iostream>
#include "dogumTarihi.h" 
#include "Isim.h"
#include "Ders.h"
#include "Ogrenci.h"
#include "Menu.h"

using namespace std;  

// ��renci ders kay�t projesi
// Mucit Yaz�l�m 
// Sad�k �AH�N- Bilgisayar M�hendisi


int main(   ) {
	 
 	 
	 Menu m1; 
	 m1.giris() ; 
	 


	return 0;
}

